# Docs

This repo contains the source files for the Micro documentation hosted at https://micro.mu/docs

## Suggestions?

Please feel free to suggest new docs. Either open an issue or PR yourself.

