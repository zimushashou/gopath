---
title: Users
keywords: users
tags: [users]
sidebar: home_sidebar
permalink: users.html
summary: 
---

If you're using Micro, feel free to add your company

### Companies

- [AdCamie](http://adcamie.com/)
- [Arex](https://arex.io/)
- [Dark Cubed](http://darkcubed.com)
- [Hightech](https://hightech.fm/)
- [Human Ventures](https://humanventures.co/)
- [Imgur](https://imgur.com/)
- [Jumia](https://food.jumia.com/)
- [Karhoo](https://karhoo.com/)
- [Kazoup](http://www.kazoup.com)
- [Kyperion](https://kyperion.com)
- [Neds](https://www.neds.com.au/)
- [Pie](http://pie.io/)
- [Reserve](https://reserve.com/)
- [Riverbed](https://www.riverbed.com/gb/)
- [TodayTix](https://www.todaytix.com/)
- [Savvy](https://www.joinsavvy.com/en/)
- [Sipsynergy](http://www.sipsynergy.co.uk/)
- [Sixt](https://www.sixt.com)
- [Stillwater Supercomputing](http://www.stillwater-sc.com/)
- [Vimeo](https://vimeo.com/)
- [Wonderbly](https://www.wonderbly.com/)

{% include links.html %}
