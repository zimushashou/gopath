---
title: Roadmap
keywords: roadmap
tags: [roadmap]
sidebar: home_sidebar
permalink: roadmap.html
summary: 
---

The roadmap displays larger milestones or just gives visibility to whats going on

## Project

We're using GitHub projects to manage the roadmap

[https://github.com/micro/micro/projects/1](https://github.com/micro/micro/projects/1)


{% include links.html %}
