# Sponsors & Backers

Micro is an open source ecosystem focused on simplifying cloud native development.

The development of micro is made possible by our sponsors and backers. We owe a great deal of debt and gratitude to them. 
If you'd like to join them please consider:

- [Becoming a sponsor via Patreon](https://www.patreon.com/microhq)
- [Making a one-time donation](https://micro.mu/#one-off-donation)

## Enterprise Sponsors ($5k+)

<a href="https://micro.mu/blog/2016/04/25/announcing-sixt-sponsorship.html"><img src="https://micro.mu/sixt_logo.png" width=150px height="auto" /></a>

## Gold Sponsors ($500)

<a href="https://www.neds.com.au/"><img src="https://micro.mu/images/logos/neds.svg" height="60px"></a>

## Generous Backers ($50)

- Joseph Jacks

## Backers

- Brian Ketelsen
- Ewan Valentine
- Stefan Hans
- Alexandre Roba
