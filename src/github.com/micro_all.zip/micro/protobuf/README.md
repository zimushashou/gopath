This repo is deprecated

Please see https://github.com/micro/protoc-gen-micro
