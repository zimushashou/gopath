package main

import _ "github.com/micro/protobuf/protoc-gen-go/micro"
