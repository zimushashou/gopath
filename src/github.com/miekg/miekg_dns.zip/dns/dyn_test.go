package dns

// Find better solution
